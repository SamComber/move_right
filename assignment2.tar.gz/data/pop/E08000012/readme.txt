CDRC 2013 Mid-Year Total Population Estimates Geodata Pack: Liverpool (E08000012)


+ Abstract
This geodata pack provides ONS total population estimates as at 30 June 2013 for those LSOAs covering the Local Authority District: Liverpool (E08000012)


+ Contents
	 - readme.txt: Information about the CDRC Geodata pack
	 - metadata.xml: Metadata
	 - tables: Folder containing the csv files
	 - shapefiles: Folder containing the shapefiles


+ Citation and Copyright
The following attribution statements must be used to acknowledge copyright and source in use of these datasets:
               Contains National Statistics data © Crown copyright and database right 2015;
               Contains Ordnance Survey data © Crown copyright and database right 2015;
               Data provided by the ESRC Consumer Data Research Centre.


+ Funding
Funded by: Economic and Social Research Council ES/L011840/1
