Dataset of tweets for Liverpool
-------------------------------

This folder contains a shapefile with geo-referenced postings to Twitter. The
data was originally provided by Guy Lansley from UCL and processed by Dani
Arribas-Bel.

For education use only. Redistribution is not permitted.

